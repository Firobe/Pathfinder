uniform int occurence;

void main()
{
    gl_FragColor.r = gl_Color.r;
    gl_FragColor.g = gl_Color.g;
    gl_FragColor.b = gl_Color.b;
}