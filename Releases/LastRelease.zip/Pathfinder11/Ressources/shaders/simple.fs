uniform vec2 resolution;
 
void main()
{
    gl_FragColor = gl_Color;
}